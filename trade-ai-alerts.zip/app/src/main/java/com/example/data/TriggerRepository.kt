package com.example.data

import kotlinx.coroutines.flow.Flow

class TriggerRepository(private val dao: TriggerDao) {
    val allTriggers: Flow<List<Trigger>> = dao.getAllTriggers()

    suspend fun getActiveTriggers() = dao.getActiveTriggers()

    suspend fun insert(trigger: Trigger) = dao.insertTrigger(trigger)

    suspend fun updateStatus(id: Int, isActive: Boolean) = dao.updateTriggerStatus(id, isActive)
    
    suspend fun deleteById(id: Int) = dao.deleteTriggerById(id)
}
