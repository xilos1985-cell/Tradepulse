package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "triggers")
data class Trigger(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userPrompt: String,
    val symbol: String,
    val parsedJson: String,
    val isActive: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)
