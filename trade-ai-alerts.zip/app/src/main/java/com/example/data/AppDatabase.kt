package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Trigger::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun triggerDao(): TriggerDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "trade_ai_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
