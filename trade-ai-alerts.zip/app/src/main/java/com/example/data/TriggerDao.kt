package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TriggerDao {
    @Query("SELECT * FROM triggers ORDER BY timestamp DESC")
    fun getAllTriggers(): Flow<List<Trigger>>

    @Query("SELECT * FROM triggers WHERE isActive = 1")
    suspend fun getActiveTriggers(): List<Trigger>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrigger(trigger: Trigger)

    @Query("UPDATE triggers SET isActive = :isActive WHERE id = :id")
    suspend fun updateTriggerStatus(id: Int, isActive: Boolean)

    @Query("DELETE FROM triggers WHERE id = :id")
    suspend fun deleteTriggerById(id: Int)
}
