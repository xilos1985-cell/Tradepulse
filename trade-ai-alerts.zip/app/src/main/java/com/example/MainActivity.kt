package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDatabase
import com.example.data.TriggerRepository
import com.example.ui.MainViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.network.BiQuoteTick
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(this)
        val repository = TriggerRepository(database.triggerDao())
        val factory = ViewModelFactory(repository)

        setContent {
            MyApplicationTheme {
                val viewModel: MainViewModel = viewModel(factory = factory)
                TradeAlertsApp(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeAlertsApp(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    var showAddDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.alerts.collect { alert ->
            snackbarHostState.showSnackbar(
                message = "${alert.symbol}: ${alert.message}",
                duration = SnackbarDuration.Short
            )
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            BottomNavigation()
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "FOREX AI INTELLIGENCE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                    Text(
                        text = "OmniAlert Pro",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = (-0.5).sp
                        ),
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = androidx.compose.foundation.shape.CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "JD",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // Ticker
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(androidx.compose.foundation.rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TickerCard(
                    symbol = "EUR/USD",
                    tick = state.livePrices["EURUSD"],
                    isDark = false
                )
                TickerCard(
                    symbol = "XAU/USD",
                    tick = state.livePrices["XAUUSD"],
                    isDark = true
                )
                TickerCard(
                    symbol = "BTC/USD",
                    tick = state.livePrices["BTCUSD"],
                    isDark = false
                )
            }

            // Main Content Area
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // AI Command Center
                Surface(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(32.dp),
                    color = MaterialTheme.colorScheme.tertiary,
                    border = androidx.compose.foundation.BorderStroke(1.dp, com.example.ui.theme.CommandCenterBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "AI COMMAND CENTER",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        Surface(
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                            color = Color.White.copy(alpha = 0.6f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White),
                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 100.dp)
                        ) {
                            Box(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "\"Alert me when the BB hits the upper line with RSI lower than 30 level on EUR/USD...\"",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(modifier = Modifier.size(8.dp).background(com.example.ui.theme.GreenText, androidx.compose.foundation.shape.CircleShape))
                                Text(
                                    text = "GPT-4o Engine Active",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            Button(
                                onClick = { showAddDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                shape = androidx.compose.foundation.shape.CircleShape,
                                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                            ) {
                                Text("Set Trigger", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Active Monitors
                Surface(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(32.dp),
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth().weight(1f)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ACTIVE MONITORS",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.2).sp),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Surface(
                                shape = androidx.compose.foundation.shape.CircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "${state.triggers.size} / 3 FREE SLOTS",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                )
                            }
                        }

                        if (state.isLoading && state.triggers.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator()
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(state.triggers, key = { it.id }) { trigger ->
                                    ActiveMonitorItem(
                                        symbol = trigger.symbol,
                                        description = trigger.userPrompt,
                                        onDelete = { viewModel.deleteTrigger(trigger.id) }
                                    )
                                }
                                
                                item {
                                    UpgradeCard(onUpgradeClick = { viewModel.showUpgradeDialog() })
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var promptText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Ask AI to monitor") },
            text = {
                OutlinedTextField(
                    value = promptText,
                    onValueChange = { promptText = it },
                    placeholder = { Text("e.g. alert me when the bb is hitted the upper lone with rsi lower than 30 level for EURUSD") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (promptText.isNotBlank()) {
                            viewModel.addTrigger(promptText)
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (state.showUpgradeDialog) {
        val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
        AlertDialog(
            onDismissRequest = { viewModel.dismissUpgradeDialog() },
            title = { Text("Upgrade to Pro 💎") },
            text = { 
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Unlock unlimited monitoring by making a payment of $19 (USDT TRC20).")
                    Text("Payment Address:", fontWeight = FontWeight.Bold)
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "TD7Y5KgSe3D2CJckdpejx6Kx72AxBUi81k",
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { 
                    clipboardManager.setText(androidx.compose.ui.text.AnnotatedString("TD7Y5KgSe3D2CJckdpejx6Kx72AxBUi81k"))
                }) {
                    Text("Copy Address")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissUpgradeDialog() }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
fun TickerCard(symbol: String, tick: BiQuoteTick?, isDark: Boolean) {
    val bgColor = if (isDark) com.example.ui.theme.CardBgDark else com.example.ui.theme.CardBgLight
    val textColor = if (isDark) Color.White else com.example.ui.theme.TextDark
    val subTextColor = if (isDark) Color(0xFFC1C7CE) else com.example.ui.theme.SubtextDark
    val highlightColor = if (symbol.contains("XAU")) com.example.ui.theme.YellowHighlight else com.example.ui.theme.BlueHighlight

    // Formatting fallback
    val priceStr = if (tick != null) String.format("%.5f", tick.mid) else "0.00000"
    
    // Split price roughly into main, highlight (last 2-3 digits), and small (last digit) for styling
    val priceMain = if (priceStr.length >= 4) priceStr.substring(0, priceStr.length - 3) else priceStr
    val priceHighlight = if (priceStr.length >= 3) priceStr.substring(priceStr.length - 3, priceStr.length - 1) else ""
    val priceSmall = if (priceStr.isNotEmpty()) priceStr.substring(priceStr.length - 1) else ""

    val changeVal = tick?.dayDiffPercent ?: 0.0
    val changeStr = if (changeVal >= 0) String.format("+%.2f%%", changeVal) else String.format("%.2f%%", changeVal)
    val changeColor = if (changeVal >= 0) com.example.ui.theme.GreenText else com.example.ui.theme.RedText

    Surface(
        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
        color = bgColor,
        border = if (!isDark) androidx.compose.foundation.BorderStroke(1.dp, Color.White) else null,
        modifier = Modifier.width(140.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = symbol,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                color = subTextColor,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = priceMain,
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, letterSpacing = (-1).sp),
                    color = textColor
                )
                Text(
                    text = priceHighlight,
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, letterSpacing = (-1).sp, textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline),
                    color = highlightColor
                )
                Text(
                    text = priceSmall,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Normal),
                    color = textColor,
                    modifier = Modifier.padding(bottom = 2.dp)
                )
            }
            Text(
                text = changeStr,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = changeColor,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun ActiveMonitorItem(symbol: String, description: String, onDelete: () -> Unit) {
    Surface(
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        color = com.example.ui.theme.ActiveMonitorBg,
        border = androidx.compose.foundation.BorderStroke(1.dp, com.example.ui.theme.ActiveMonitorBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                    color = Color.White,
                    border = androidx.compose.foundation.BorderStroke(1.dp, com.example.ui.theme.ActiveMonitorBorder),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("📈", style = MaterialTheme.typography.bodyLarge)
                    }
                }
                Column {
                    Text(
                        text = description,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                    Text(
                        text = "$symbol • Real-time",
                        style = MaterialTheme.typography.labelSmall,
                        color = com.example.ui.theme.TextMuted
                    )
                }
            }
            
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
fun UpgradeCard(onUpgradeClick: () -> Unit) {
    Surface(
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.errorContainer,
        border = androidx.compose.foundation.BorderStroke(1.dp, com.example.ui.theme.UpgradeBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "UPGRADE REQUIRED",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = "Unlock unlimited monitoring for 28+ pairs, indices, and crypto.",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                color = com.example.ui.theme.UpgradeText,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Button(
                onClick = onUpgradeClick,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Go Unlimited • $19/mo", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
fun BottomNavigation() {
    Surface(
        color = MaterialTheme.colorScheme.background,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth().height(80.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem(icon = "⌂", label = "Markets", isActive = true)
            NavItem(icon = "⚑", label = "Alerts", isActive = false)
            NavItem(icon = "❈", label = "AI Chat", isActive = false)
            NavItem(icon = "⚙", label = "Settings", isActive = false)
        }
    }
}

@Composable
fun NavItem(icon: String, label: String, isActive: Boolean) {
    val color = if (isActive) MaterialTheme.colorScheme.secondary else com.example.ui.theme.NavInactive.copy(alpha = 0.6f)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (isActive) {
            Surface(
                shape = androidx.compose.foundation.shape.CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            ) {
                Text(
                    text = icon,
                    style = MaterialTheme.typography.titleLarge,
                    color = color,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                )
            }
        } else {
            Text(
                text = icon,
                style = MaterialTheme.typography.titleLarge,
                color = color,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = color
        )
    }
}
