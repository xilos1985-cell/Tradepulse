package com.example.network

import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

data class Message(val role: String, val content: String)
data class ChatRequest(val model: String = "gpt-4o", val messages: List<Message>, val temperature: Double = 0.0)
data class ChatChoice(val message: Message)
data class ChatResponse(val choices: List<ChatChoice>)

interface OpenAiApi {
    @POST("v1/chat/completions")
    suspend fun createChatCompletion(
        @Header("Authorization") authHeader: String,
        @Body request: ChatRequest
    ): ChatResponse
}
