package com.example.network

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

data class OhlcCandle(
    val openTime: String,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val tickVolume: Long,
    val isOpen: Boolean
)

data class BiQuoteTick(
    val symbol: String,
    val mid: Double,
    val dayDiffPercent: Double,
    val description: String?
)

interface BiQuoteApi {
    @GET("api/{symbol}/ohlc")
    suspend fun getOhlc(
        @Path("symbol") symbol: String,
        @Query("timeframe") timeframe: String = "M1",
        @Query("limit") limit: Int = 50
    ): List<OhlcCandle>

    @GET("api/latest")
    suspend fun getLatestTicks(
        @Query("symbols") symbols: List<String>
    ): Map<String, BiQuoteTick>
}
