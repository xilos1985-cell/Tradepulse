package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Trigger
import com.example.data.TriggerRepository
import com.example.domain.IndicatorEvaluator
import com.example.network.ChatChoice
import com.example.network.ChatRequest
import com.example.network.Message
import com.example.network.NetworkModule
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import com.example.BuildConfig

import com.example.network.BiQuoteTick

data class AppState(
    val triggers: List<Trigger> = emptyList(),
    val livePrices: Map<String, BiQuoteTick> = emptyMap(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val showUpgradeDialog: Boolean = false
)

data class AlertNotification(val symbol: String, val message: String, val time: Long = System.currentTimeMillis())

class MainViewModel(private val repository: TriggerRepository) : ViewModel() {

    private val _state = MutableStateFlow(AppState())
    val state: StateFlow<AppState> = _state.asStateFlow()

    private val _alerts = MutableSharedFlow<AlertNotification>()
    val alerts: SharedFlow<AlertNotification> = _alerts.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.allTriggers.collect { triggers ->
                _state.update { it.copy(triggers = triggers) }
            }
        }
        
        startMonitoring()
    }

    private fun startMonitoring() {
        viewModelScope.launch {
            while (true) {
                try {
                    val prices = NetworkModule.biQuoteApi.getLatestTicks(listOf("EURUSD", "XAUUSD", "BTCUSD"))
                    _state.update { it.copy(livePrices = prices) }
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                val activeTriggers = repository.getActiveTriggers()
                for (trigger in activeTriggers) {
                    try {
                        val candles = NetworkModule.biQuoteApi.getOhlc(trigger.symbol, "M1", 50)
                        val isMet = IndicatorEvaluator.evaluate(candles, trigger.parsedJson)
                        if (isMet) {
                            _alerts.emit(AlertNotification(trigger.symbol, "Condition met: ${trigger.userPrompt}"))
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                delay(10000) // Poll every 10 seconds for prototype (real-time simulation)
            }
        }
    }

    fun addTrigger(prompt: String) {
        viewModelScope.launch {
            val currentActive = state.value.triggers.count { it.isActive }
            if (currentActive >= 3) {
                _state.update { it.copy(showUpgradeDialog = true) }
                return@launch
            }

            _state.update { it.copy(isLoading = true, error = null) }
            try {
                // Parse using OpenAI
                val request = ChatRequest(
                    messages = listOf(
                        Message("system", "Extract the trading symbol (e.g., EURUSD, XAUUSD, BTCUSD, AAPL) and conditions from the user's trading alert prompt. Return a raw JSON object with 'symbol' and 'conditions' array. Example conditions: RSI < 30, BB_UPPER. Only return valid JSON, no markdown formatting or extra text."),
                        Message("user", prompt)
                    )
                )
                val response = NetworkModule.openAiApi.createChatCompletion(
                    authHeader = "Bearer ${BuildConfig.OPENAI_API_KEY}",
                    request = request
                )
                val rawJson = response.choices.firstOrNull()?.message?.content?.trim()?.removePrefix("```json")?.removeSuffix("```") ?: "{}"
                
                // Extract symbol as a simple regex/string operation for prototype
                val symbolMatch = Regex("\"symbol\"\\s*:\\s*\"([A-Za-z0-9]+)\"").find(rawJson)
                val symbol = symbolMatch?.groupValues?.get(1)?.uppercase() ?: "EURUSD"

                val trigger = Trigger(
                    userPrompt = prompt,
                    symbol = symbol,
                    parsedJson = rawJson
                )
                repository.insert(trigger)
            } catch (e: Exception) {
                _state.update { it.copy(error = e.localizedMessage) }
            } finally {
                _state.update { it.copy(isLoading = false) }
            }
        }
    }

    fun deleteTrigger(id: Int) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }

    fun showUpgradeDialog() {
        _state.update { it.copy(showUpgradeDialog = true) }
    }

    fun dismissUpgradeDialog() {
        _state.update { it.copy(showUpgradeDialog = false) }
    }
}
