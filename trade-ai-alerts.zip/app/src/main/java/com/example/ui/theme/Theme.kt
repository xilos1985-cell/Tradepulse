package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = ButtonPrimary,
    secondary = TextDark,
    tertiary = CommandCenterBg,
    background = BgColor,
    surface = BgColor,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = TextDark,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = CardBgLight,
    onSurfaceVariant = SubtextDark,
    primaryContainer = HeaderIconBg,
    onPrimaryContainer = HeaderIconText,
    error = UpgradeButton,
    errorContainer = UpgradeBg,
    onErrorContainer = UpgradeTitle
  )

private val LightColorScheme =
  lightColorScheme(
    primary = ButtonPrimary,
    secondary = TextDark,
    tertiary = CommandCenterBg,
    background = BgColor,
    surface = BgColor,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = TextDark,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = CardBgLight,
    onSurfaceVariant = SubtextDark,
    primaryContainer = HeaderIconBg,
    onPrimaryContainer = HeaderIconText,
    error = UpgradeButton,
    errorContainer = UpgradeBg,
    onErrorContainer = UpgradeTitle
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false, // Disable dynamic colors to enforce Sleek Interface
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
