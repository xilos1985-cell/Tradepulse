package com.example.domain

import com.example.network.OhlcCandle
import kotlin.math.pow
import kotlin.math.sqrt

object IndicatorEvaluator {

    fun evaluate(candles: List<OhlcCandle>, parsedJson: String): Boolean {
        // Fallback or empty logic
        if (candles.isEmpty()) return false
        
        try {
            // Simplified JSON parsing (since we use Moshi elsewhere, we can use it here)
            // But we'll just do basic logic for RSI and BB
            val closes = candles.map { it.close }
            val latestPrice = closes.first() // BiQuote history is newest first

            val rsi = calculateRsi(closes, 14)
            val bb = calculateBollingerBands(closes, 20, 2.0)

            // Extremely simplified evaluator based on string contains for prototyping
            // In a real app, parse the JSON properly.
            val jsonLower = parsedJson.lowercase()
            
            var conditionMet = true

            // RSI checks
            if (jsonLower.contains("rsi")) {
                if (jsonLower.contains("<") && jsonLower.contains("30")) {
                    if (rsi >= 30) conditionMet = false
                }
                if (jsonLower.contains(">") && jsonLower.contains("70")) {
                    if (rsi <= 70) conditionMet = false
                }
            }

            // BB checks
            if (jsonLower.contains("bb_upper") || jsonLower.contains("upper")) {
                if (latestPrice < bb.upper) conditionMet = false
            }
            if (jsonLower.contains("bb_lower") || jsonLower.contains("lower")) {
                if (latestPrice > bb.lower) conditionMet = false
            }

            return conditionMet

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    private fun calculateRsi(closesNewestFirst: List<Double>, period: Int): Double {
        if (closesNewestFirst.size <= period) return 50.0
        
        // Reverse to oldest first for calculation
        val closes = closesNewestFirst.reversed()
        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val diff = closes[i] - closes[i - 1]
            if (diff >= 0) gains += diff else losses -= diff
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in period + 1 until closes.size) {
            val diff = closes[i] - closes[i - 1]
            val gain = if (diff >= 0) diff else 0.0
            val loss = if (diff < 0) -diff else 0.0

            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1 + rs))
    }

    data class BollingerBands(val lower: Double, val middle: Double, val upper: Double)

    private fun calculateBollingerBands(closesNewestFirst: List<Double>, period: Int, stdDevMultiplier: Double): BollingerBands {
        if (closesNewestFirst.size < period) return BollingerBands(0.0, 0.0, 0.0)
        
        // Take the latest `period` candles
        val recentCloses = closesNewestFirst.take(period)
        val sma = recentCloses.average()
        
        val variance = recentCloses.map { (it - sma).pow(2) }.average()
        val stdDev = sqrt(variance)

        return BollingerBands(
            lower = sma - stdDevMultiplier * stdDev,
            middle = sma,
            upper = sma + stdDevMultiplier * stdDev
        )
    }
}
